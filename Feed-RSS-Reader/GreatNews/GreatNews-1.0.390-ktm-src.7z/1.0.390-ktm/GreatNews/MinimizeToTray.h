#ifndef _MINIMIZE_TO_TRAY_H_
#define _MINIMIZE_TO_TRAY_H_

VOID MinimizeWndToTray(HWND hWnd);
VOID RestoreWndFromTray(HWND hWnd);

#endif // _MINIMIZE_TO_TRAY_H_
