//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GreatNewsLngEditor.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define ID_FILE_OPENRIGHT               32772
#define ID_FILE_COPYTORIGHT             32774
#define ID_EDIT_COPYTORIGHT             32776
#define ID_EDIT_COPYONELINE             32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
