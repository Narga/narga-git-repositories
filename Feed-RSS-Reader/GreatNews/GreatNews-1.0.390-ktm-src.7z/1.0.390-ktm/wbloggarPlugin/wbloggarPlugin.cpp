//
// 1) GreatNews plugin dll should export the following two functions:
//		LPCTSTR __stdcall GetGreatNewsPluginName();
//		void __stdcall BlogThis(LPCTSTR itemXml, LPCTSTR options);
//
// 2) Copy the plugin dll into GreatNews \Plugins directory. It will show up
// in BlogThis configuration dialog (Tools->Options->Features->Config BlogThis)
//
// 3) This is a sample plugin, which only has the bare minimium error handling.
//

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
// Windows Header Files:
#include <windows.h>
#include <tchar.h>

#include <atlstr.h>
#include <atlfile.h>
#include <atlbase.h>

#import "msxml3.dll"

BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved )
{
    return TRUE;
}

////////////////////////////////////////////////////////////////////////
// Parameters: None
// Return Value: The name of the plugin
//
LPCTSTR __stdcall GetGreatNewsPluginName()
{
	return _T("GreatNews w.Bloggar Plugin 1.0");
}

///////////////////////////////////////////////////////////////////////
// Parameters:	itemXml : the news item and its channel in rss 2.0 format
//				options : the url paramter set in BlogThis configuration dialog
// Return Value: None
//
void __stdcall BlogThis(LPCTSTR itemXml, LPCTSTR options)
{
	try
	{
		MSXML2::IXMLDOMDocument2Ptr spDoc(_T("MSXML2.DOMDocument.3.0"));
		spDoc->loadXML(itemXml);

		//
		// create output html
		//
		_bstr_t title = spDoc->selectSingleNode(_T("/rss/channel/item/title"))->text;
		_bstr_t content = spDoc->selectSingleNode(_T("/rss/channel/item/description"))->text;
		_bstr_t url = spDoc->selectSingleNode(_T("/rss/channel/item/link"))->text;

		CString wBloggarInput;
		wBloggarInput.Format(_T("<blockquote><a href=\"%s\">%s</a><br>%s</blockquote>"), (LPCTSTR)url, (LPCTSTR)title, (LPCTSTR)content);

		//
		// save to a temp file
		//
	    TCHAR szTempFileName[MAX_PATH];
        ::GetTempPath(MAX_PATH, szTempFileName);
        ::GetTempFileName(szTempFileName, _T("w"), 0, szTempFileName);
		CAtlFile file;
		HRESULT hr=file.Create(szTempFileName,GENERIC_WRITE, FILE_SHARE_WRITE, CREATE_ALWAYS, FILE_FLAG_SEQUENTIAL_SCAN );
		USES_CONVERSION;
 		file.Write(T2A(wBloggarInput), wBloggarInput.GetLength());
		file.Close();
	
		//
		// invoke w.Bloggar with the file
		//
		LONG lResult = 0;
		CRegKey reg;
		lResult = reg.Open(HKEY_CURRENT_USER,_T("Software\\VB and VBA Program Settings\\Bloggar"));
		if(ERROR_SUCCESS != lResult)
		{
			::MessageBox(NULL, _T("Cannot find w.Bloggar..."), _T("w.Bloggar plugin"), MB_OK|MB_ICONINFORMATION);
			return;
		}   
		CString wBloggarPath;
		ULONG size = MAX_PATH;
		reg.QueryStringValue(_T("InstallPath"), wBloggarPath.GetBuffer(size), &size);
		TCHAR wBloggarCmdLine[MAX_PATH];
		_stprintf_s(wBloggarCmdLine, MAX_PATH, _T("\"%s\\wbloggar.exe\" \"%s\""), (LPCTSTR)wBloggarPath, szTempFileName);
		STARTUPINFO si;
		memset(&si, 0, sizeof(STARTUPINFO));
		si.cb = sizeof(STARTUPINFO);
		PROCESS_INFORMATION pi;
		::CreateProcess(NULL, wBloggarCmdLine, NULL, NULL, false, CREATE_DEFAULT_ERROR_MODE, NULL, NULL, &si, &pi);
	}
	catch(...)
	{
		::MessageBox(NULL, _T("Something failed in w.Bloggar plugin..."), _T("w.Bloggar plugin"), MB_ICONINFORMATION|MB_OK);
	}
}
