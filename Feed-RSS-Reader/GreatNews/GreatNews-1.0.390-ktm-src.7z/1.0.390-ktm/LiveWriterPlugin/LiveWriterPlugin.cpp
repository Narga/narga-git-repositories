// LiveWriterPlugin.cpp : Defines the entry point for the DLL application.
//

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
// Windows Header Files:
#include <windows.h>
#include <tchar.h>

#include <atlstr.h>
#include <atlfile.h>
#include <atlbase.h>

#import "msxml3.dll"
#import "WindowsLiveWriter.Application.tlb" rename_namespace("LiveWriter")

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

////////////////////////////////////////////////////////////////////////
// Parameters: None
// Return Value: The name of the plugin
//
LPCTSTR __stdcall GetGreatNewsPluginName()
{
	return _T("GreatNews LiveWriter Plugin 1.0");
}

///////////////////////////////////////////////////////////////////////
// Parameters:	itemXml : the news item and its channel in rss 2.0 format
//				options : the url paramter set in BlogThis configuration dialog
// Return Value: None
//
void __stdcall BlogThis(LPCTSTR itemXml, LPCTSTR options)
{
	try
	{
		MSXML2::IXMLDOMDocument2Ptr spDoc(_T("MSXML2.DOMDocument.3.0"));
		spDoc->loadXML(itemXml);

		//
		// create output html
		//
		_bstr_t title = spDoc->selectSingleNode(_T("/rss/channel/item/title"))->text;
		_bstr_t content = spDoc->selectSingleNode(_T("/rss/channel/item/description"))->text;
		_bstr_t url = spDoc->selectSingleNode(_T("/rss/channel/item/link"))->text;

		// launch LiveWriter
		LiveWriter::IWindowsLiveWriterApplicationPtr liveWriterPtr(__uuidof(LiveWriter::WindowsLiveWriterApplication));
		liveWriterPtr->BlogThisLink(title, url, content);
	}
	catch(_com_error& e)
	{
		CString error = "Failed to use LiveWriter. ";
		error += e.ErrorMessage();
		::MessageBox(NULL, error, _T("LiveWriter Plugin"), MB_ICONINFORMATION|MB_OK);
	}
	catch(...)
	{
		::MessageBox(NULL, _T("Something failed in LiveWriter plugin..."), _T("LiveWriter Plugin"), MB_ICONINFORMATION|MB_OK);
	}
}
